﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.BL
{
    public class CrrendentialBL
    {
        private string Username;
        private string Pass;
        private string Role;
        public CrrendentialBL(string username, string pass, string role)
        {
            this.Username = username;
            this.Pass = pass;
            this.Role = role;
        }
        public CrrendentialBL(string username, string pass)
        {
            this.Username = username;
            this.Pass = pass;
        }
        public void SetName(string name)
        {
            this.Username = name;
        }
        public void SetPass(string pass)
        {
            this.Pass = pass;
        }
        public void SetRole(string role)
        {
            this.Role = role;
        }
        public string GetName()
        {
            return this.Username;
        }
        public string GetPass()
        {
            return this.Pass;
        }
        public string GetRole()
        {
            return this.Role;
        }
    }
}
