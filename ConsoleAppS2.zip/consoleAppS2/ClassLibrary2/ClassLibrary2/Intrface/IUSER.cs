﻿using ClassLibrary2.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.Interface
{
    public interface IUSER
    {        
        bool Add(CrrendentialBL user);
        bool Update(CrrendentialBL user);
        bool DeleteStudentByRoll(string UserName);
        List<CrrendentialBL> GetAllStudents();
        string Check(CrrendentialBL User);
    }
}