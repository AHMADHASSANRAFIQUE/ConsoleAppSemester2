﻿using ClassLibrary2.BL;
using ClassLibrary2.Interface;
using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.DL
{
    public class ReviewsDL
    {
        public static bool AddFeedBack(ReviewBL review)
        {
            string name = "00";
            bool chec = CheckUsernameExists(review.GetUserName());
            if (chec) 
            {
                name = review.GetUserName();
            }
            else 
            {
                return false;
            }
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            //try
            //{
            con.Open(); 
            SqlCommand command = new SqlCommand("INSERT INTO [Review] (FeedBack, UserName) VALUES (@Feedback, @Name)", con);
            command.Parameters.AddWithValue("@Feedback", review.GetFeedBack());
            command.Parameters.AddWithValue("@Name", name);
            // Execute your SqlCommand here

            int r = command.ExecuteNonQuery();
            con.Close();
            return true;

            //}
            //catch
            //{
            //  return false;
            //}
            //finally
            //{
            //  con.Close();
            //}
        }
        private static bool CheckUsernameExists(string username)
        {
            string connectionString = Utility.GetConnectionString();
            string query = "SELECT COUNT(*) FROM UserData WHERE UserName = @Username";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    // Add parameter with correct data type and size
                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar, 50).Value = username;

                    con.Open();
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }



        public static bool AddRating(ReviewBL review)
        {
            string name = "00";
            bool chec = CheckUsernameExists(review.GetUserName());
            if (chec)
            {
                name = review.GetUserName();
            }
            else
            {
                return false;
            }
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("INSERT INTO [Review] (Rating, UserName) VALUES (@Rating, (SELECT UserName FROM [UserData] WHERE UserName = @Name))", con);
                command.Parameters.AddWithValue("@Rating", review.GetRating());
                command.Parameters.AddWithValue("@Name", name);

                // Execute your SqlCommand here

                int r = command.ExecuteNonQuery();
                return true;

            }
            catch
            {
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        public static bool AddComplain(ReviewBL review)
        {
            string name = "00";
            bool chec = CheckUsernameExists(review.GetUserName());
            if (chec)
            {
                name = review.GetUserName();
            }
            else
            {
                return false;
            }
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("INSERT INTO [Review] (Complains, UserName) VALUES (@Complains, (SELECT UserName FROM [UserData] WHERE UserName = @Name))", con);
                command.Parameters.AddWithValue("@Complains", review.GetComplains());
                command.Parameters.AddWithValue("@Name", name);

                // Execute your SqlCommand here

                int r = command.ExecuteNonQuery();
                return true;

            }
            catch
            {
                return false;
            }
            finally
            {
                con.Close();
            }
        }

        public static List<ReviewBL> GetAllReviews()
        {
            List<ReviewBL> list = new List<ReviewBL>();
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM [Review]";
                SqlCommand cmd = new SqlCommand(query, connection);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        string name = Convert.ToString(reader["UserName"]);
                        string feedback = Convert.ToString(reader["Feedback"]);
                        string rating = Convert.ToString(reader["Rating"]);
                        string complains = Convert.ToString(reader["Complains"]);
                        ReviewBL student = new ReviewBL(feedback, name, rating, complains);
                        list.Add(student);
                    }
                }
            }

            return list;
        }

    }
}
