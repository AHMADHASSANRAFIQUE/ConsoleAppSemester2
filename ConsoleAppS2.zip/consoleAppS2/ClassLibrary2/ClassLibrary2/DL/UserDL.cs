﻿using ClassLibrary2.BL;
using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary2.Interface;

namespace ClassLibrary2.DL
{
    public class UserDL : IUSER
    {
        public bool Add(CrrendentialBL user)
        {
            string conn = Utility.GetConnectionString();
            using (SqlConnection con = new SqlConnection(conn))
            {
                //try
                //{
                    con.Open();
                    if (user.GetRole() == "Customer")
                    {
                        SqlCommand command = new SqlCommand("INSERT INTO [UserData] (UserName, Password, Role, Address) VALUES (@Name, @pass, @role, @address)", con);
                        command.Parameters.AddWithValue("@Name", user.GetName());
                        command.Parameters.AddWithValue("@pass", user.GetPass());
                        command.Parameters.AddWithValue("@role", user.GetRole());
                        // Typecast user to CustomerBL to access GetAddress()
                        CustomerBL customer = (CustomerBL)user;
                        command.Parameters.AddWithValue("@address", customer.GetAddress());
                        int r = command.ExecuteNonQuery();
                        return true;
                    }
                    else
                    {
                        SqlCommand command = new SqlCommand("INSERT INTO [UserData] (UserName, Password, Role, Phone) VALUES (@Name, @pass, @role, @phone)", con);
                        command.Parameters.AddWithValue("@Name", user.GetName());
                        command.Parameters.AddWithValue("@pass", user.GetPass());
                        command.Parameters.AddWithValue("@role", user.GetRole());

                        EmployeeBL employee = (EmployeeBL)user;
                        command.Parameters.AddWithValue("@phone", employee.GetPhone());
                        int r = command.ExecuteNonQuery();
                        return true;
                    }
                //}
                //catch
                //{
                  //  return false;
                //}
            }
        }

        public bool Update(CrrendentialBL user)
        {
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            string query = string.Format("UPDATE UserData SET Password = @pass WHERE UserName = '{0}'", user.GetName());
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@pass", user.GetPass());            
            int r = command.ExecuteNonQuery();
            con.Close();
            if (r > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool DeleteStudentByRoll(string UserName)
        {
            string connectiongString = Utility.GetConnectionString();
            SqlConnection connection = new SqlConnection(connectiongString);
            connection.Open();

            string query = "DELETE FROM [UserData] WHERE UserName = @UserName";
            SqlCommand cmd = new SqlCommand(query, connection);

            cmd.Parameters.AddWithValue("@UserName", UserName);

            int rows = cmd.ExecuteNonQuery();

            connection.Close();
            string Name = UserName;
            removeStudent(Name);
            if (rows > 0)
            {
                return true;
            }
            else { return false; }
        }
        public void removeStudent(string studentId)
        {
            List<CrrendentialBL> list = GetAllStudents();
            foreach (CrrendentialBL student in list)
            {
                if (student.GetName() == studentId)
                {
                    list.Remove(student);
                }
            }
        }
        public List<CrrendentialBL> GetAllStudents()
        {
            List<CrrendentialBL> list = new List<CrrendentialBL>();
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM [UserData]";
                SqlCommand cmd = new SqlCommand(query, connection);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {

                        string name = Convert.ToString(reader["UserName"]);

                        string matric = Convert.ToString(reader["Password"]);
                        string ecat = Convert.ToString(reader["Role"]);
                        CrrendentialBL student = new CrrendentialBL(name, matric, ecat);                        
                        list.Add(student);
                    }
                }
            }

            return list;
        }
        public string Check(CrrendentialBL User)
        {
            string sta = null, id = null, role = null;
            string connectionString = "Data Source=DESKTOP-QI6H2EA;Initial Catalog=Signup;Integrated Security=True;Encrypt=False;Trusted_Connection=True";
            string query = string.Format("SELECT UserName, Password, Role FROM UserData WHERE UserName = '{0}' AND Password = '{1}'", User.GetName(), User.GetPass());

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            sta = reader.GetString(0); // Use GetString to retrieve string values from the reader
                            id = reader.GetString(1);
                            role = reader.GetString(2);
                        }
                    }
                }
            }

            if (sta == User.GetName() && id == User.GetPass())
            {
                return role;
            }
            else
            {
                return role;
            }
        }
    }
}
