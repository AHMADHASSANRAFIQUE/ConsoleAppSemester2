﻿using ClassLibrary2.BL;
using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClassLibrary2.DL
{
    public class ProductDL
    {
        public static bool Add(ProductBL product)
        {
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("INSERT INTO [ProductData] (Name, Price, Quantity, Discount, Catagory) VALUES (@Name, @price, @quantity, @discount, @catagory)", con);
                command.Parameters.AddWithValue("@Name", product.GetName());
                command.Parameters.AddWithValue("@price", product.GetPrice());
                command.Parameters.AddWithValue("@quantity", product.GetQuantity());
                command.Parameters.AddWithValue("@discount", product.GetDiscount());
                command.Parameters.AddWithValue("@catagory", product.GetCatagory());

                // Execute your SqlCommand here

                int r = command.ExecuteNonQuery();
                return true;

            }
            catch
            {
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        public static bool Update(ProductBL product)
        {
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            string query = string.Format("UPDATE ProductData SET Price = @price, Quantity = @quantity, Discount = @discount, Catagory = @catagory WHERE Name = '{0}'", product.GetName());
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@Name", product.GetName());
            command.Parameters.AddWithValue("@price", product.GetPrice());
            command.Parameters.AddWithValue("@quantity", product.GetQuantity());
            command.Parameters.AddWithValue("@discount", product.GetDiscount());
            command.Parameters.AddWithValue("@catagory", product.GetCatagory());

            int r = command.ExecuteNonQuery();
            con.Close();
            if (r > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool Delete(string Name)
        {
            string connectiongString = Utility.GetConnectionString();
            SqlConnection connection = new SqlConnection(connectiongString);
            connection.Open();

            string query = "DELETE FROM [ProductData] WHERE Name = @name";
            SqlCommand cmd = new SqlCommand(query, connection);

            cmd.Parameters.AddWithValue("@name", Name);

            int rows = cmd.ExecuteNonQuery();

            connection.Close();
            string Namee = Name;
            removefromlist(Namee);
            if (rows > 0)
            {
                return true;
            }
            else { return false; }
        }
        public static void removefromlist(string name)
        {
            List<ProductBL> list = GetAllStudents();
            foreach (ProductBL product in list)
            {
                if (product.GetName() == name)
                {
                    list.Remove(product);
                }
            }
        }
        public static List<ProductBL> GetAllStudents()
        {
            List<ProductBL> list = new List<ProductBL>();
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM [ProductData]";
                SqlCommand cmd = new SqlCommand(query, connection);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string name = Convert.ToString(reader["Name"]);
                        float price = Convert.ToSingle(reader["Price"]);
                        int quantity = Convert.ToInt32(reader["Quantity"]);
                        float discount = Convert.ToSingle(reader["Discount"]);
                        string catagory = Convert.ToString(reader["Catagory"]);

                        ProductBL product = new ProductBL(name, price, quantity, discount, catagory);
                        list.Add(product);
                    }
                }
            }

            return list;
        }

        public static bool UpdateStock(string name, int quantity)
        {
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            string query = string.Format("UPDATE ProductData SET Quantity = @quantity WHERE Name = '{0}'", name);
            SqlCommand command = new SqlCommand(query, con);

            command.Parameters.AddWithValue("@quantity", quantity);

            int r = command.ExecuteNonQuery();
            con.Close();
            if (r > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool UpdateDiscount(string name, float discount)
        {
            string conn = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            string query = string.Format("UPDATE ProductData SET Discount = @quantity WHERE Name = '{0}'", name);
            SqlCommand command = new SqlCommand(query, con);

            command.Parameters.AddWithValue("@quantity", discount);

            int r = command.ExecuteNonQuery();
            con.Close();
            if (r > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static float GetCurrentDiscountFromDatabase(string name)
        {
            float discount = 0;
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Discount FROM ProductData WHERE Name = @name"; // Assuming ProductId is the identifier for your product

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", name); // Replace yourProductId with the actual product ID

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            discount = Convert.ToSingle(reader["Discount"]);
                        }
                    }
                    connection.Close();

                    return discount;

                }
            }
        }
        public static int GetCurrentStockFromDatabase(string name)
        {
            int discount = 0;
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Quantity FROM ProductData WHERE Name = @name"; // Assuming ProductId is the identifier for your product

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", name); // Replace yourProductId with the actual product ID

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            discount = Convert.ToInt32(reader["Quantity"]);
                        }
                    }
                    connection.Close();

                    return discount;

                }
            }
        }

        public static List<ProductBL> GetAllCrispyItems()
        {
            List<ProductBL> list = new List<ProductBL>();
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string Name = "Crispy Items";
                string query = "SELECT * FROM [ProductData] where Catagory = @name";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", Name);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string name = Convert.ToString(reader["Name"]);
                        float price = Convert.ToSingle(reader["Price"]);
                        int quantity = Convert.ToInt32(reader["Quantity"]);
                        float discount = Convert.ToSingle(reader["Discount"]);
                        string catagory = Convert.ToString(reader["Catagory"]);

                        ProductBL product = new ProductBL(name, price, quantity, discount, catagory);
                        list.Add(product);
                    }
                }
            }

            return list;
        }
        public static List<ProductBL> GetAllFastFood()
        {
            List<ProductBL> list = new List<ProductBL>();
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string Name = "Fast Food";
                string query = "SELECT * FROM [ProductData] where Catagory = @name";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", Name);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string name = Convert.ToString(reader["Name"]);
                        float price = Convert.ToSingle(reader["Price"]);
                        int quantity = Convert.ToInt32(reader["Quantity"]);
                        float discount = Convert.ToSingle(reader["Discount"]);
                        string catagory = Convert.ToString(reader["Catagory"]);

                        ProductBL product = new ProductBL(name, price, quantity, discount, catagory);
                        list.Add(product);
                    }
                }
            }

            return list;
        }
        public static List<ProductBL> GetAllBeverages()
        {
            List<ProductBL> list = new List<ProductBL>();
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string Name = "Beverages";
                string query = "SELECT * FROM [ProductData] where Catagory = @name";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", Name);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string name = Convert.ToString(reader["Name"]);
                        float price = Convert.ToSingle(reader["Price"]);
                        int quantity = Convert.ToInt32(reader["Quantity"]);
                        float discount = Convert.ToSingle(reader["Discount"]);
                        string catagory = Convert.ToString(reader["Catagory"]);

                        ProductBL product = new ProductBL(name, price, quantity, discount, catagory);
                        list.Add(product);
                    }
                }
            }

            return list;
        }
        public static List<ProductBL> GetAllSiders()
        {
            List<ProductBL> list = new List<ProductBL>();
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string Name = "Siders";
                string query = "SELECT * FROM [ProductData] where Catagory = @name";
                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@name", Name);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string name = Convert.ToString(reader["Name"]);
                        float price = Convert.ToSingle(reader["Price"]);
                        int quantity = Convert.ToInt32(reader["Quantity"]);
                        float discount = Convert.ToSingle(reader["Discount"]);
                        string catagory = Convert.ToString(reader["Catagory"]);

                        ProductBL product = new ProductBL(name, price, quantity, discount, catagory);
                        list.Add(product);
                    }
                }
            }

            return list;
        }
    }
}
