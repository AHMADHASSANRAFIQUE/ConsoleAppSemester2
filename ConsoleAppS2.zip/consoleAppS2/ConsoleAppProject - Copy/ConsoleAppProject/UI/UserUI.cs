﻿using ClassLibrary2.BL;
using ClassLibrary2.Utils;
using ClassLibrary2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary2.Interface;

namespace ConsoleAppProject.UI
{
    public class UserUI
    {        
        public static IUSER USER = ObjectHandler.GetUserDB();
        public void HandleUserInput(string choice)
        {
            switch (choice)
            {
                case "1":
                    ConsoleUtility.ClearHeader();
                    DeleteUser();
                    break;
                case "2":
                    ConsoleUtility.ClearHeader();
                    SignUp();
                    break;                
                case "3":
                    ConsoleUtility.ClearHeader();
                    AddEmployee();
                    break;
                case "4":
                    ConsoleUtility.ClearHeader();
                    UpdateUser();
                    break;
                case "5":
                    ConsoleUtility.ClearHeader();
                    string res = SignIn();
                    if(res == "Customer")
                    {
                        Console.WriteLine("This is Customer");
                    }
                    else if (res == "Employee")
                    {
                        Console.WriteLine("This is Employee");
                    }
                    else if (res == "Admin")
                    {
                        Console.WriteLine("This is Admin");
                    }
                    else
                    {
                        Console.WriteLine("Error!");
                    }
                    break;
                case "6":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice!");
                    break;
            }
        }

        public void DeleteUser()
        {
            Console.WriteLine("\n-------------- DELETE USER --------------\n");
            Console.WriteLine("Enter username:");
            string username = Console.ReadLine();

            bool result = USER.DeleteStudentByRoll(username);

            if (result)
            {
                Console.WriteLine("Successfully Deleted");
                Console.Read();
            }
            else
            {
                Console.WriteLine("Error!");
                Console.Read();
            }
        }
        public string SignIn()
        {
            Console.WriteLine("\n-------------- SIGN IN--------------\n");
            Console.WriteLine("Enter username:");
            string username = Console.ReadLine();

            Console.WriteLine("Enter password:");
            string password = Console.ReadLine();

            CrrendentialBL data = new CrrendentialBL(username, password);
            string result = USER.Check(data);
            return result;
        }
        public void SignUp()
        {
            Console.WriteLine("\n-------------- ADD CUSTOMER --------------\n");
            Console.WriteLine("Enter username:");
            string username = Console.ReadLine();

            Console.WriteLine("Enter password:");
            string password = Console.ReadLine();

            if (Utility.checker(username))
            {
                if (Utility.ValidatePassword(password))
                {
                    Console.WriteLine("Enter Address:");
                    string additionalInfo = Console.ReadLine();

                    CrrendentialBL data = new CustomerBL(username, password, "Customer", additionalInfo);
                    bool result = USER.Add(data);

                    if (result)
                    {
                        Console.WriteLine("Successfully Signed Up");
                        Console.Read();
                    }
                    else
                    {
                        Console.WriteLine("Username Already Exists!");
                        Console.Read();
                    }
                }
                else
                {
                    Console.WriteLine("Password Must be 4 digits");
                    Console.Read();
                }
            }
            else
            {
                Console.WriteLine("Username Cannot Contain ',' !!");
                Console.Read();
            }
        }

        public void AddEmployee()
        {
            Console.WriteLine("\n-------------- ADD EMPLOYEE --------------\n");
            Console.WriteLine("Enter username:");
            string username = Console.ReadLine();

            Console.WriteLine("Enter password:");
            string password = Console.ReadLine();

            if (Utility.checker(username))
            {
                if (Utility.ValidatePassword(password))
                {
                    Console.WriteLine("Enter Phone:");
                    int additionalInfo = int.Parse(Console.ReadLine());

                    CrrendentialBL data = new EmployeeBL(username, password, "Employee", additionalInfo);
                    bool result = USER.Add(data);

                    if (result)
                    {
                        Console.WriteLine("Successfully Signed Up");
                        Console.Read();
                    }
                    else
                    {
                        Console.WriteLine("Username Already Exists!");
                        Console.Read();
                    }
                }
                else
                {
                    Console.WriteLine("Password Must be 4 digits");
                    Console.Read();
                }
            }
            else
            {
                Console.WriteLine("Username Cannot Contain ',' !!");
                Console.Read();
            }
        }

        public void UpdateUser()
        {
            Console.WriteLine("\n-------------- UPDATE USER --------------\n");
            Console.WriteLine("Enter username:");
            string username = Console.ReadLine();

            Console.WriteLine("Enter new password:");
            string newPassword = Console.ReadLine();

            if (Utility.ValidatePassword(newPassword))
            {
                CrrendentialBL data = new CrrendentialBL(username, newPassword, "Customer");
                bool result = USER.Update(data);

                if (result)
                {
                    Console.WriteLine("Successfully Updated");
                    Console.Read();
                }
                else
                {
                    Console.WriteLine("Error!");
                    Console.Read();
                }
            }
            else
            {
                Console.WriteLine("Password Must be 4 digits");
                Console.Read();
            }
        }
    }
}
