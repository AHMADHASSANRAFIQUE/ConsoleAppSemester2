﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppProject.UI
{
    internal class ConsoleUtility
    {
        public static void Logo()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"
                                                                                                            
                                                                                                            
                                                                                                            
                                                                                                            
                                                                                                            
                                                                                                            
                 ____   ______ ______   ____               __                                     __        
                / __ ) / ____// ____/  / __ \ ___   _____ / /_ ____ _ __  __ _____ ____ _ ____   / /_       
               / __  |/ /_   / /      / /_/ // _ \ / ___// __// __ `// / / // ___// __ `// __ \ / __/       
              / /_/ // __/  / /___   / _, _//  __/(__  )/ /_ / /_/ // /_/ // /   / /_/ // / / // /_         
             /_____//_/     \____/  /_/ |_| \___//____/ \__/ \__,_/ \__,_//_/    \__,_//_/ /_/ \__/         
                                                                                                            
                 ______                              __     _           __           __                     
                /_  __/____  _      __ ____   _____ / /_   (_)____     / /   ____ _ / /_   ____   _____ ___ 
                 / /  / __ \| | /| / // __ \ / ___// __ \ / // __ \   / /   / __ `// __ \ / __ \ / ___// _ \
                / /  / /_/ /| |/ |/ // / / /(__  )/ / / // // /_/ /  / /___/ /_/ // / / // /_/ // /   /  __/
               /_/   \____/ |__/|__//_/ /_//____//_/ /_//_// .___/  /_____/\__,_//_/ /_/ \____//_/    \___/ 
                                                          /_/                                               
");
            Console.ResetColor();
        }


        public static void ClearScreen()
        {
            Console.WriteLine("\nPress Any Key to Continue..");
            Console.ReadKey();
            Console.Clear();
        }

        public static void ClearHeader()
        {
            Console.Clear();
            Logo();
        }
        public static string DisplayMenu()
        {
            Console.WriteLine("Enter your choice:");
            Console.WriteLine("1. Delete User");
            Console.WriteLine("2. Add Customer");
            Console.WriteLine("3. Add Employee");
            Console.WriteLine("4. Update User");
            Console.WriteLine("5. Sign In");
            Console.WriteLine("6. Exit");
            Console.Write("Your option is .... ");
            string option = Console.ReadLine();

            return option;
        }
    }
}
