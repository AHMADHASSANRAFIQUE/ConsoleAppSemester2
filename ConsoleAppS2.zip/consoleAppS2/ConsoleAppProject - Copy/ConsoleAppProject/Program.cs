﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary2;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using ClassLibrary2.BL;
using ConsoleAppProject.UI;

namespace ConsoleAppProject
{
    using System;

    public class Program
    {
        public static void Main()
        {
            UserUI userUI = new UserUI();

            while (true)
            {
                ConsoleUtility.ClearHeader();
                string choice = ConsoleUtility.DisplayMenu();                
                userUI.HandleUserInput(choice);
                Console.Read();
                ConsoleUtility.ClearHeader();
            }
        }
    }

}
