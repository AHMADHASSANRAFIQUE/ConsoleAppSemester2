﻿using ClassLibrary2.BL;
using ClassLibrary2.Interface;
using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ClassLibrary2.DL
{
    public class UserFH : IUSER
    {
        public List<CrrendentialBL> usersList;
        public bool Add(CrrendentialBL user)
        {
            string filePath = Utility.GetPath(); // Assuming UserData.txt is the file to store user data
            try
            {
                ObjectHandler.GetUserDB().Add(user);
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    // Format the user data as a line in the file
                    string userDataLine = $"{user.GetName()}, {user.GetPass()}, {user.GetRole()}";
                    writer.WriteLine(userDataLine);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool Update(CrrendentialBL user)
        {
            usersList = GetAllStudents();
            // Find the user in usersList based on UserName
            CrrendentialBL existingUser = usersList.Find(u => u.GetName() == user.GetName());

            if (existingUser != null)
            {
                ObjectHandler.GetUserDB().Update(user);
                // Update the existing user's information
                existingUser.SetPass(user.GetPass());
                existingUser.SetRole(user.GetRole());
                SaveToFile();
                return true; // User successfully updated
            }
            else
            {
                // Add the new user to usersList
                usersList.Add(user);
                return false; // User added as it didn't exist before
            }
        }



        public bool DeleteStudentByRoll(string UserName)
        {
            usersList = GetAllStudents();
            CrrendentialBL userToDelete = usersList.Find(u => u.GetName() == UserName);

            if (userToDelete != null)
            {
                ObjectHandler.GetUserDB().DeleteStudentByRoll(UserName);
                usersList.Remove(userToDelete);
                SaveToFile();
                return true; // User successfully deleted
            }
            else
            {
                return false; // User not found in the list
            }
            
        }
        public string Check(CrrendentialBL User)
        {
            
            string filePath = Utility.GetPath(); // Assuming UserData.txt contains user data
            string role = null;
            
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] userData = line.Split(',');

                    if (userData.Length >= 3 && userData[0].Trim() == User.GetName() && userData[1].Trim() == User.GetPass())
                    {
                        role = userData[2].Trim();
                        break;
                    }
                }
            }                        
            return role;
        }
        public void SaveToFile()
        {
            string filePath = Utility.GetPath(); // Specify the file path where you want to store the data

            try
            {
                // Clear the file by creating a new StreamWriter with FileMode.Create
                using (StreamWriter clearWriter = new StreamWriter(filePath, false))
                {
                    clearWriter.Write("");
                }

                // Append new data to the file using StreamWriter with append mode
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    foreach (CrrendentialBL user in usersList)
                    {
                        string userDataLine = $"{user.GetName()}, {user.GetPass()}, {user.GetRole()}";
                        writer.WriteLine(userDataLine);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error writing to file: " + ex.Message);
            }
        }


        public List<CrrendentialBL> GetAllStudents()
        {
            List<CrrendentialBL> list = new List<CrrendentialBL>();
            string filePath = Utility.GetPath(); // Assuming UserData.txt contains user data            
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] userData = line.Split(',');

                    if (userData.Length >= 3)
                    {
                        string name = userData[0].Trim();
                        string pass = userData[1].Trim();
                        string role = userData[2].Trim();

                        CrrendentialBL student = new CrrendentialBL(name, pass, role);
                        list.Add(student);
                    }
                }
            }            
            return list;
        }        
    }
}
